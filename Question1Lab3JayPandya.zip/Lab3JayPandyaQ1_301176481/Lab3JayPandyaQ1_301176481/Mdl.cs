﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab3JayPandyaQ1_301176481
{
    public class Mnlst
    {
        public Mnlst(string nameOFProduct, double priceOfProduct)
        {
            ItemName = nameOFProduct;
            ItemPrice = priceOfProduct;
        }

        public string ItemName { get; set; }
        public double ItemPrice { get; set; }
    }


    public class OrderedItem : Mnlst, INotifyPropertyChanged
    {
        public OrderedItem(string name, double price) : base(name, price)
        {
            Quantity = 1;
        }

        private int qnt;

        public event PropertyChangedEventHandler PropertyChanged;

        public int Quantity
        {
            get
            {
                return qnt;
            }
            set
            {
                qnt = value;
            }
        }

        protected void RaisePropertyChanged(string propertyName)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }

    }

    public class Mdl : INotifyPropertyChanged
    {
        public event PropertyChangedEventHandler PropertyChanged;

        public Mdl()
        {
            Total = Tax = SubTotal = 0.0;
            Beverages = new ObservableCollection<Mnlst>()
{
new Mnlst("Soda", 1.95),
new Mnlst("Tea", 1.50),
new Mnlst("Coffee", 1.25),
new Mnlst("Mineral Water", 2.95),
new Mnlst("Juice", 2.50),
new Mnlst("Milk", 1.50)
};

            MainCourse = new ObservableCollection<Mnlst>()
{
new Mnlst("Chicken Alfredo", 13.95),
new Mnlst("Chicken Picatta", 13.95),
new Mnlst("Turkey Club", 11.95),
new Mnlst("Lobster Pie", 19.95),
new Mnlst("Prime Rib", 20.95),
new Mnlst("Shrimp Scampi", 18.95),
new Mnlst("Turkey Dinner", 13.95),
new Mnlst("Stuffed Chicken", 14.95)
};

            Appetizer = new ObservableCollection<Mnlst>()
{
new Mnlst("Buffalo Wings", 5.95),
new Mnlst("Buffalo Fingers", 6.95),
new Mnlst("Potato Skins", 8.95),
new Mnlst("Nachos", 8.95),
new Mnlst("Mushroom Caps", 10.95),
new Mnlst("Chips and Salsa", 6.95)
};

            Dessert = new ObservableCollection<Mnlst>()
{
new Mnlst("Apple Pie", 5.95),
new Mnlst("Sundae", 3.95),
new Mnlst("Carrot Cake", 5.95),
new Mnlst("Mud Pie", 4.95),
new Mnlst("Apple Crisp", 5.95)
};

            Order = new ObservableCollection<OrderedItem>();
        }

        public ObservableCollection<Mnlst> Beverages { get; set; }

        public ObservableCollection<Mnlst> MainCourse { get; set; }

        public ObservableCollection<Mnlst> Appetizer { get; set; }

        public ObservableCollection<Mnlst> Dessert { get; set; }

        public ObservableCollection<OrderedItem> Order { get; set; }

        private double ttlCost;

        public double Total
        {
            get { return ttlCost; }
            set
            {
                ttlCost = value;
                RaisePropertyChanged(nameof(Total));
            }
        }

        private double tax;

        public double Tax
        {
            get { return tax; }
            set
            {
                tax = value;
                RaisePropertyChanged(nameof(Tax));
            }
        }

        private double subTotal;

        public double SubTotal
        {
            get { return subTotal; }
            set
            {
                subTotal = value;
                RaisePropertyChanged(nameof(SubTotal));
            }
        }

        protected void RaisePropertyChanged(string propertyName)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }

        public void ReBill()
        {
            Total = Tax = SubTotal = 0.0;
            foreach (var item in Order)
            {
                Total += item.ItemPrice * item.Quantity;
            }
            Tax = Total * 0.13; 
            SubTotal = Total + Tax;
        }

        public void clrBill()
        {
            Total = Tax = SubTotal = 0.0;
        }
    }
}


