﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Lab3JayPandyaQ1_301176481
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
            DataContext = new Mdl();
        }

        private void ComboBox_SelectionChanged(object sender, System.Windows.Controls.SelectionChangedEventArgs e)
        {
            var dtcontxt = DataContext as Mdl;
            var item = e.AddedItems[0] as Mnlst;
            if (dtcontxt == null || item == null)
                return;

            if (dtcontxt.Order.Any(o => o.ItemName == item.ItemName))
            {
                var orderItem = dtcontxt.Order.First(o => o.ItemName == item.ItemName);
                orderItem.Quantity++;
            }
            else
            {
                dtcontxt.Order.Add(new OrderedItem(item.ItemName, item.ItemPrice));
            }

            dtcontxt.ReBill();
        }

        private void ClearBill_Executed(object sender, ExecutedRoutedEventArgs e)
        {
            var dataContext = DataContext as Mdl;
            dataContext.clrBill();
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            var dataContext = DataContext as Mdl;
            dataContext.clrBill();
        }
    }
}
